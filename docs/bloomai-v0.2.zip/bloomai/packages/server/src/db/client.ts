import initSqlJs, { Database as SqlJsDatabase } from 'sql.js'
import path from 'path'
import fs from 'fs'
import os from 'os'

const DATA_DIR = process.env.DATA_DIR || path.join(os.homedir(), '.bloomai')
const DB_PATH = path.join(DATA_DIR, 'bloomai.db')

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true })
}

let dbInstance: SqlJsDatabase | null = null

function saveDb() {
  if (!dbInstance) return
  const data = dbInstance.export()
  fs.writeFileSync(DB_PATH, Buffer.from(data))
}

export let db: any = null

export async function initDb() {
  if (dbInstance && db) return db
  const SQL = await initSqlJs()
  if (fs.existsSync(DB_PATH)) {
    dbInstance = new SQL.Database(fs.readFileSync(DB_PATH))
  } else {
    dbInstance = new SQL.Database()
  }

  db = {
    prepare(sql: string) {
      return {
        run: (...params: any[]) => {
          dbInstance!.run(sql, params.flat())
          saveDb()
          return { changes: 1 }
        },
        get: (...params: any[]) => {
          const stmt = dbInstance!.prepare(sql)
          stmt.bind(params.flat())
          if (stmt.step()) { const r = stmt.getAsObject(); stmt.free(); return r }
          stmt.free(); return undefined
        },
        all: (...params: any[]) => {
          const rows: any[] = []
          const stmt = dbInstance!.prepare(sql)
          stmt.bind(params.flat())
          while (stmt.step()) rows.push(stmt.getAsObject())
          stmt.free(); return rows
        }
      }
    },
    exec(sql: string) { dbInstance!.run(sql); saveDb() },
    transaction(fn: (items: any[]) => void) {
      return (items: any[]) => { fn(items); saveDb() }
    }
  }
  return db
}

export async function runMigrations() {
  await initDb()

  db.exec(`
    CREATE TABLE IF NOT EXISTS personas (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, system_prompt TEXT NOT NULL,
      model_override TEXT, is_builtin INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT 'New Chat',
      persona_id TEXT, model TEXT NOT NULL DEFAULT 'claude-3-5-sonnet-20241022',
      status TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY, session_id TEXT NOT NULL, role TEXT NOT NULL,
      content TEXT NOT NULL, tool_calls TEXT, tokens INTEGER, created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, created_at);
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at INTEGER NOT NULL);
  `)

  db.exec(`
    CREATE TABLE IF NOT EXISTS tools (
      id TEXT PRIMARY KEY, category TEXT NOT NULL, name TEXT NOT NULL,
      description TEXT NOT NULL, params_schema TEXT NOT NULL DEFAULT '{}',
      result_schema TEXT NOT NULL DEFAULT '{}', is_builtin INTEGER DEFAULT 1,
      is_enabled INTEGER DEFAULT 1, requires_permission TEXT, created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tool_runs (
      id TEXT PRIMARY KEY, tool_id TEXT NOT NULL, session_id TEXT,
      input_json TEXT NOT NULL, output_json TEXT, status TEXT NOT NULL,
      error_msg TEXT, duration_ms INTEGER, started_at INTEGER NOT NULL, finished_at INTEGER
    );
    CREATE TABLE IF NOT EXISTS tool_permissions (
      id TEXT PRIMARY KEY, tool_id TEXT NOT NULL, granted INTEGER DEFAULT 0,
      granted_at INTEGER, scope TEXT DEFAULT 'session'
    );
    CREATE TABLE IF NOT EXISTS skills (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
      type TEXT NOT NULL, source TEXT NOT NULL, params_schema TEXT NOT NULL DEFAULT '{}',
      author TEXT, version TEXT DEFAULT '1.0.0', is_public INTEGER DEFAULT 0,
      is_installed INTEGER DEFAULT 1, install_count INTEGER DEFAULT 0, created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS skill_runs (
      id TEXT PRIMARY KEY, skill_id TEXT NOT NULL, input_json TEXT NOT NULL,
      output_json TEXT, status TEXT NOT NULL, duration_ms INTEGER, created_at INTEGER NOT NULL
    );
  `)

  const pCount = db.prepare("SELECT COUNT(*) as c FROM personas WHERE is_builtin=1").get() as any
  if (!pCount || pCount.c === 0) {
    const now = Date.now()
    for (const [id, name, prompt, model] of [
      ['developer','Developer','You are an expert software engineer. Help with code review, debugging, and architecture. Prefer TypeScript.','claude-3-5-sonnet-20241022'],
      ['writer','Writer','You are a professional content writer. Help with writing, editing, clarity and tone.','claude-3-5-sonnet-20241022'],
      ['analyst','Analyst','You are a data analyst. Provide precise insights with numbers.','claude-3-opus-20240229'],
      ['translator','Translator','You are a professional translator for Chinese, English, Japanese and Korean.','claude-3-5-sonnet-20241022'],
      ['coach','Coach','You are a life and productivity coach. Help with goals and decisions.','claude-3-5-sonnet-20241022'],
    ]) {
      db.prepare("INSERT OR IGNORE INTO personas(id,name,system_prompt,model_override,is_builtin,created_at) VALUES(?,?,?,?,1,?)")
        .run(id, name, prompt, model, now)
    }
  }

  for (const [k, v] of [
    ['model','claude-3-5-sonnet-20241022'],['theme','system'],
    ['shortcut_overlay','Alt+Space'],['anthropic_api_key',''],
    ['openai_api_key',''],['clipboard_monitoring','true'],['context_awareness','true'],
  ]) {
    db.prepare("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES(?,?,?)").run(k, v, Date.now())
  }

  const tCount = db.prepare("SELECT COUNT(*) as c FROM tools WHERE is_builtin=1").get() as any
  if (!tCount || tCount.c === 0) {
    const now = Date.now()
    const tools = [
      ['web_search','web','Web Search','Search the web and return relevant results with titles, URLs and snippets.','{"query":{"type":"string"},"limit":{"type":"number","default":8}}','{"results":{"type":"array"}}',null],
      ['web_fetch','web','Web Fetch','Fetch and extract the main text content from a webpage URL.','{"url":{"type":"string"},"mode":{"type":"string","enum":["text","html"],"default":"text"}}','{"title":{"type":"string"},"content":{"type":"string"}}','network'],
      ['web_screenshot','web','Web Screenshot','Capture a full-page screenshot of any URL as PNG.','{"url":{"type":"string"}}','{"imagePath":{"type":"string"}}','network'],
      ['web_extract','web','Web Extract','Extract structured data (links, headings, tables) from a webpage.','{"url":{"type":"string"},"selector":{"type":"string"}}','{"headings":{"type":"array"},"links":{"type":"array"}}','network'],
      ['fs_read','fs','File Read','Read the contents of a local file with optional line range.','{"path":{"type":"string"},"offset":{"type":"number"},"limit":{"type":"number"}}','{"content":{"type":"string"},"totalLines":{"type":"number"}}','fs'],
      ['fs_write','fs','File Write','Write or append content to a local file.','{"path":{"type":"string"},"content":{"type":"string"},"mode":{"type":"string","enum":["write","append"],"default":"write"}}','{"bytesWritten":{"type":"number"}}','write'],
      ['fs_edit','fs','File Edit','Replace an exact unique string in a file.','{"path":{"type":"string"},"oldText":{"type":"string"},"newText":{"type":"string"}}','{"success":{"type":"boolean"},"linesChanged":{"type":"number"}}','write'],
      ['fs_grep','fs','File Grep','Search file(s) for a regex pattern, return matching lines with line numbers.','{"pattern":{"type":"string"},"path":{"type":"string"},"recursive":{"type":"boolean"}}','{"matches":{"type":"array"}}','fs'],
      ['fs_glob','fs','File Glob','Find files matching a glob pattern.','{"pattern":{"type":"string"},"cwd":{"type":"string"}}','{"files":{"type":"array"}}','fs'],
      ['bash','fs','Bash','Execute whitelisted shell commands (ls, cat, grep, find, head, tail, wc).','{"command":{"type":"string"},"cwd":{"type":"string"}}','{"stdout":{"type":"string"},"stderr":{"type":"string"},"exitCode":{"type":"number"}}','shell'],
      ['doc_markdown','document','Markdown Parser','Parse Markdown to extract headings, text, code blocks and links.','{"path":{"type":"string"}}','{"text":{"type":"string"},"headings":{"type":"array"},"codeBlocks":{"type":"array"}}','fs'],
      ['doc_pdf','document','PDF Parser','Extract text, page count and metadata from a PDF file.','{"path":{"type":"string"},"pages":{"type":"array"}}','{"text":{"type":"string"},"numPages":{"type":"number"},"metadata":{"type":"object"}}','fs'],
      ['doc_txt','document','Text File','Read plain text with auto encoding detection and chunking.','{"path":{"type":"string"},"chunkSize":{"type":"number"}}','{"text":{"type":"string"},"encoding":{"type":"string"},"chunks":{"type":"array"}}','fs'],
      ['doc_csv','document','CSV Parser','Parse CSV/TSV to rows with column stats.','{"path":{"type":"string"},"limit":{"type":"number"}}','{"headers":{"type":"array"},"rows":{"type":"array"},"stats":{"type":"object"}}','fs'],
      ['doc_docx','document','DOCX Parser','Convert .docx to plain text or HTML.','{"path":{"type":"string"},"format":{"type":"string","enum":["text","html"],"default":"text"}}','{"text":{"type":"string"},"html":{"type":"string"}}','fs'],
      ['vision','multimodal','Vision','Analyze image content and answer questions about what is in the image.','{"imagePath":{"type":"string"},"imageUrl":{"type":"string"},"question":{"type":"string","default":"Describe this image in detail."}}','{"description":{"type":"string"}}','network'],
      ['ocr','multimodal','OCR','Extract text from an image or screenshot using OCR.','{"imagePath":{"type":"string"},"lang":{"type":"string","default":"eng"}}','{"text":{"type":"string"},"confidence":{"type":"number"}}','fs'],
      ['image_gen','multimodal','Image Generator','Generate an image from a text prompt using DALL-E 3.','{"prompt":{"type":"string"},"size":{"type":"string","default":"1024x1024"},"quality":{"type":"string","default":"standard"},"saveTo":{"type":"string"}}','{"url":{"type":"string"},"localPath":{"type":"string"}}','network'],
      ['image_edit','multimodal','Image Editor','Resize, crop, convert format or compress an image using sharp.','{"path":{"type":"string"},"ops":{"type":"array"},"outputPath":{"type":"string"}}','{"outputPath":{"type":"string"},"size":{"type":"number"},"format":{"type":"string"}}','fs'],
      ['node_runner','execution','Node Runner','Execute JavaScript in a sandboxed vm context.','{"code":{"type":"string"},"context":{"type":"object"}}','{"result":{"type":"any"},"logs":{"type":"array"},"error":{"type":"string"}}','sandbox'],
      ['python_runner','execution','Python Runner','Run Python 3 code in a restricted subprocess with timeout.','{"code":{"type":"string"},"packages":{"type":"array"}}','{"stdout":{"type":"string"},"stderr":{"type":"string"},"exitCode":{"type":"number"}}','sandbox'],
      ['shell','execution','Shell','Full shell access — requires explicit permanent permission.','{"command":{"type":"string"},"cwd":{"type":"string"},"env":{"type":"object"}}','{"stdout":{"type":"string"},"stderr":{"type":"string"},"exitCode":{"type":"number"}}','shell'],
    ]
    for (const [id, cat, name, desc, params, result, perm] of tools) {
      db.prepare("INSERT OR IGNORE INTO tools(id,category,name,description,params_schema,result_schema,is_builtin,is_enabled,requires_permission,created_at) VALUES(?,?,?,?,?,?,1,1,?,?)")
        .run(id, cat, name, desc, params, result, perm, now)
    }
  }

  const sCount = db.prepare("SELECT COUNT(*) as c FROM skills WHERE author='official'").get() as any
  if (!sCount || sCount.c === 0) {
    const now = Date.now()
    const skills = [
      ['web-search-skill','Web Search','Search the web and return results','http-api',
       JSON.stringify({url:'https://api.searxng.org/search?q={{query}}&format=json',method:'GET'}),
       '{"query":{"type":"string","description":"Search query"}}','official','1.0.0',1,1248],
      ['text-summarizer','Text Summarizer','Summarize any text into key points','prompt-template',
       'Summarize the following text in 3-5 bullet points:\n\n{{text}}',
       '{"text":{"type":"string","description":"Text to summarize"}}','official','1.0.0',1,892],
      ['code-explainer','Code Explainer','Explain what a code snippet does','prompt-template',
       'Explain what this code does step by step:\n\n```\n{{code}}\n```',
       '{"code":{"type":"string","description":"Code snippet"}}','official','1.0.0',1,634],
      ['translator-skill','Auto Translator','Translate text between languages','prompt-template',
       'Translate the following text to {{targetLang}}. Only output the translation:\n\n{{text}}',
       '{"text":{"type":"string"},"targetLang":{"type":"string","description":"Target language"}}','official','1.0.0',1,1103],
      ['keyword-extractor','Keyword Extractor','Extract keywords and hashtags from content','js-function',
       'function run(input) {\n  const words = input.text.toLowerCase().split(/[\\s,\uff0c\u3002\uff01\uff1f]+/).filter(w => w.length > 2)\n  const freq = {}\n  words.forEach(w => { freq[w] = (freq[w]||0)+1 })\n  const keywords = Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,15).map(([w])=>w)\n  const hashtags = keywords.slice(0,10).map(k=>"#"+k)\n  return { keywords, hashtags, count: keywords.length }\n}',
       '{"text":{"type":"string","description":"Content to extract keywords from"}}','official','1.0.0',1,421],
      ['readability-checker','Readability Checker','Check text readability and suggest improvements','prompt-template',
       'Analyze the readability of this text. Score it 1-10 and give specific improvement suggestions:\n\n{{text}}',
       '{"text":{"type":"string","description":"Text to check"}}','community','1.0.0',1,287],
      ['json-formatter','JSON Formatter','Format and validate JSON data','js-function',
       'function run(input) {\n  try {\n    const parsed = JSON.parse(input.json)\n    return { formatted: JSON.stringify(parsed, null, 2), valid: true, keys: Object.keys(parsed).length }\n  } catch(e) { return { formatted: input.json, valid: false, error: e.message } }\n}',
       '{"json":{"type":"string","description":"JSON string to format"}}','community','1.0.0',1,156],
      ['data-analyzer','Data Analyzer','Statistical analysis on CSV or array data','js-function',
       'function run(input) {\n  const nums = input.data.filter(n=>typeof n==="number")\n  if(!nums.length) return { error: "No numeric data" }\n  const sum = nums.reduce((a,b)=>a+b,0)\n  const avg = sum/nums.length\n  const sorted = [...nums].sort((a,b)=>a-b)\n  return { count: nums.length, sum, avg: +avg.toFixed(4), min: sorted[0], max: sorted[sorted.length-1], median: sorted[Math.floor(sorted.length/2)] }\n}',
       '{"data":{"type":"array","description":"Array of numbers to analyze"}}','community','1.0.0',1,198],
    ]
    for (const [id, name, desc, type, source, params, author, ver, pub, cnt] of skills) {
      db.prepare("INSERT OR IGNORE INTO skills(id,name,description,type,source,params_schema,author,version,is_public,is_installed,install_count,created_at) VALUES(?,?,?,?,?,?,?,?,?,0,?,?)")
        .run(id, name, desc, type, source, params, author, ver, pub, cnt, now)
    }
  }
}
