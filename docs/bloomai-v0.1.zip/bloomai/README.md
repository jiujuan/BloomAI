# 🌸 BloomAI v0.1 — Seedling

> Local-first AI Desktop Assistant · Intelligent Chat Engine · v0.1.0

---

## What's in v0.1

BloomAI v0.1 implements the complete **Chat Engine** milestone:

| Feature | Status |
|---|---|
| Multi-turn conversation with streaming | ✅ |
| 5 built-in AI personas (Developer, Writer, Analyst, Translator, Coach) | ✅ |
| Multi-model routing (Claude 3.5 / Claude 3 Opus / GPT-4o) | ✅ |
| Session management (create / switch / delete) | ✅ |
| Message history persistent in SQLite | ✅ |
| Context pills (clipboard + active app) | ✅ |
| Markdown rendering + syntax-highlighted code blocks | ✅ |
| Dark / light / system theme | ✅ |
| 4-step Onboarding | ✅ |
| Settings (API keys, model, shortcuts, privacy) | ✅ |
| Persona editor (create / edit / delete) | ✅ |
| Keyboard shortcuts (⌘N, ⌘,, ⌘⇧D) | ✅ |
| Electron desktop shell + system tray | ✅ |
| Alt+Space overlay window | ✅ |

---

## Quick Start

### Prerequisites

- **Node.js 20+** — https://nodejs.org
- **npm 9+**
- **Anthropic API key** — https://console.anthropic.com

### Development mode (fastest way to run)

```bash
# 1. Install dependencies
cd bloomai
npm install --legacy-peer-deps --ignore-scripts

# 2. Install per-package deps
cd packages/server && npm install --legacy-peer-deps --ignore-scripts && cd ../..
cd packages/ui && npm install --legacy-peer-deps --ignore-scripts && cd ../..
cd apps/desktop && npm install --legacy-peer-deps --ignore-scripts && cd ../..

# 3. Start the backend server (terminal 1)
cd packages/server
node dist/index.js
# Server runs on http://127.0.0.1:3718

# 4. Start the frontend (terminal 2)
cd apps/desktop
npx vite
# Opens http://localhost:5173 in browser

# 5. Configure your API key
# Open Settings (⌘,) → Models → paste your Anthropic API key → Save Keys
```

### Run as pure web app (no Electron required)

```bash
# Terminal 1: Start server
cd packages/server && node dist/index.js

# Terminal 2: Start Vite dev server
cd apps/desktop && npx vite

# Open http://localhost:5173 in Chrome/Firefox
```

### Build for production

```bash
# Build server
cd packages/server && npx tsc

# Build frontend + Electron
cd apps/desktop && npx vite build

# Run built server
cd packages/server && node dist/index.js &

# Open dist/index.html in Electron or serve with npx serve dist
```

---

## Project Structure

```
bloomai/
├── packages/
│   ├── server/          # Express + sql.js backend (port 3718)
│   │   ├── src/
│   │   │   ├── db/      # SQLite client + repositories
│   │   │   ├── routes/  # chat, sessions, personas, settings
│   │   │   └── middleware/
│   │   └── dist/        # Built JS (run with node dist/index.js)
│   │
│   └── ui/              # Shared React component library
│       └── src/
│           ├── components/   # Chat, Layout, Settings, Persona, Onboarding
│           ├── stores/       # Zustand state (chat, session, persona, settings, ui)
│           └── lib/          # platform.ts, utils.ts, schemas
│
└── apps/
    └── desktop/         # Electron + Vite app
        ├── electron/    # main.ts, preload.ts
        ├── src/         # React renderer (copies from packages/ui)
        ├── dist/        # Built renderer
        └── dist-electron/  # Built Electron main/preload
```

---

## API Reference

All endpoints: `http://127.0.0.1:3718`

| Method | Path | Description |
|---|---|---|
| GET | /health | Health check |
| POST | /api/v1/chat/stream | **SSE streaming chat** |
| GET | /api/v1/sessions | List sessions |
| POST | /api/v1/sessions | Create session |
| PATCH | /api/v1/sessions/:id | Update session |
| DELETE | /api/v1/sessions/:id | Archive session |
| GET | /api/v1/sessions/:id/messages | Message history |
| GET | /api/v1/personas | List personas |
| POST | /api/v1/personas | Create persona |
| PATCH | /api/v1/personas/:id | Update persona |
| DELETE | /api/v1/personas/:id | Delete persona |
| GET | /api/v1/settings | All settings |
| PATCH | /api/v1/settings | Update settings |

### Chat stream payload

```json
POST /api/v1/chat/stream
{
  "sessionId": "uuid",
  "content": "Hello, explain async/await",
  "contextOverride": {
    "activeApp": "VS Code",
    "clipboardContent": "const fn = async () => ..."
  }
}
```

SSE response events:
```
data: {"type":"delta","text":"..."}   // streaming token
data: {"type":"done","tokens":{...}}  // completion
data: {"type":"error","error":"..."}  // error
data: [DONE]                          // end of stream
```

---

## Configuration

Settings are stored in `~/.bloomai/bloomai.db`. Configure via Settings page or API:

| Key | Default | Description |
|---|---|---|
| `anthropic_api_key` | `""` | Your Anthropic API key |
| `openai_api_key` | `""` | Your OpenAI API key (optional) |
| `model` | `claude-3-5-sonnet-20241022` | Default model |
| `theme` | `system` | `light` / `dark` / `system` |
| `clipboard_monitoring` | `true` | Auto-read clipboard for context |
| `context_awareness` | `true` | Include active app name in prompts |

---

## Built-in Personas

| ID | Name | Speciality | Default Model |
|---|---|---|---|
| `developer` | Developer | Code review, debugging, architecture | claude-3.5-sonnet |
| `writer` | Writer | Content writing, editing, clarity | claude-3.5-sonnet |
| `analyst` | Analyst | Data analysis, research, insights | claude-3-opus |
| `translator` | Translator | Chinese/English/Japanese/Korean | claude-3.5-sonnet |
| `coach` | Coach | Life coaching, goal setting, decisions | claude-3.5-sonnet |

---

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `⌘ N` / `Ctrl N` | New session |
| `⌘ ,` / `Ctrl ,` | Open settings |
| `⌘ ⇧ D` / `Ctrl ⇧ D` | Toggle dark mode |
| `Enter` | Send message |
| `Shift + Enter` | New line |
| `Alt + Space` | Toggle overlay window (Electron) |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Desktop shell | Electron 30 |
| Frontend | React 18 + TypeScript |
| State | Zustand |
| Validation | Zod |
| Styling | Tailwind CSS (custom design tokens) |
| Icons | Lucide React |
| Markdown | react-markdown |
| Backend | Express 4 |
| Database | sql.js (SQLite, zero native deps) |
| AI | Anthropic SDK (claude) |

---

## Data & Privacy

- All conversation data stored locally in `~/.bloomai/bloomai.db`
- API keys stored locally in settings DB
- No telemetry, no analytics, no cloud sync
- API calls go directly from your machine to Anthropic/OpenAI

---

## Troubleshooting

**"No API key configured"** — Open Settings → Models → enter your Anthropic API key → Save Keys

**Server won't start** — Check port 3718 is free: `lsof -i :3718`

**Blank screen** — Ensure the server is running at `http://127.0.0.1:3718/health`

**Messages not streaming** — Check browser console for CORS errors; ensure server is on port 3718

---

## Roadmap

- **v0.2 Sprout** — Tools system (web search, file read/write, OCR, image gen) + Skills market
- **v0.3 Bloom** — Multi-Agent (小红书, 公众号, Code Review agents) + Agent market
- **v0.4 Flourish** — Workflow automation (Cron triggers, NL→workflow, step editor)

---

*BloomAI v0.1.0 · Built with ❤️ · June 2026*
