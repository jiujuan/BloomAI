import initSqlJs, { Database as SqlJsDatabase } from 'sql.js'
import path from 'path'
import fs from 'fs'
import os from 'os'

const DATA_DIR = process.env.DATA_DIR || path.join(os.homedir(), '.bloomai')
const DB_PATH = path.join(DATA_DIR, 'bloomai.db')

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true })
}

let _db: SqlJsDatabase | null = null

function saveDb(db: SqlJsDatabase) {
  const data = db.export()
  fs.writeFileSync(DB_PATH, Buffer.from(data))
}

export async function getDb(): Promise<SqlJsDatabase> {
  if (_db) return _db
  const SQL = await initSqlJs()
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH)
    _db = new SQL.Database(fileBuffer)
  } else {
    _db = new SQL.Database()
  }
  return _db
}

// Synchronous wrapper - initialize eagerly
let dbInstance: SqlJsDatabase | null = null

export function getDbSync(): SqlJsDatabase {
  if (!dbInstance) throw new Error('DB not initialized. Call initDb() first.')
  return dbInstance
}

export let db: any = null

export async function initDb() {
  const SQL = await initSqlJs()
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH)
    dbInstance = new SQL.Database(fileBuffer)
  } else {
    dbInstance = new SQL.Database()
  }

  // Create adapter that mimics better-sqlite3 API
  db = {
    _db: dbInstance,
    _save() { saveDb(dbInstance!) },
    prepare(sql: string) {
      return {
        run: (...params: any[]) => {
          dbInstance!.run(sql, params)
          saveDb(dbInstance!)
          return { changes: 1 }
        },
        get: (...params: any[]) => {
          const stmt = dbInstance!.prepare(sql)
          stmt.bind(params)
          if (stmt.step()) {
            const row = stmt.getAsObject()
            stmt.free()
            return row
          }
          stmt.free()
          return undefined
        },
        all: (...params: any[]) => {
          const results: any[] = []
          const stmt = dbInstance!.prepare(sql)
          stmt.bind(params)
          while (stmt.step()) {
            results.push(stmt.getAsObject())
          }
          stmt.free()
          return results
        }
      }
    },
    exec(sql: string) {
      dbInstance!.run(sql)
      saveDb(dbInstance!)
    },
    transaction(fn: (items: any[]) => void) {
      return (items: any[]) => {
        fn(items)
        saveDb(dbInstance!)
      }
    }
  }

  return db
}

export async function runMigrations() {
  const d = await initDb()

  d.exec(`
    CREATE TABLE IF NOT EXISTS personas (
      id             TEXT PRIMARY KEY,
      name           TEXT NOT NULL,
      system_prompt  TEXT NOT NULL,
      model_override TEXT,
      is_builtin     INTEGER NOT NULL DEFAULT 0,
      created_at     INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id         TEXT PRIMARY KEY,
      title      TEXT NOT NULL DEFAULT 'New Chat',
      persona_id TEXT,
      model      TEXT NOT NULL DEFAULT 'claude-3-5-sonnet-20241022',
      status     TEXT NOT NULL DEFAULT 'active',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS messages (
      id         TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      role       TEXT NOT NULL,
      content    TEXT NOT NULL,
      tool_calls TEXT,
      tokens     INTEGER,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS settings (
      key        TEXT PRIMARY KEY,
      value      TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `)

  // Seed personas
  const count = d.prepare("SELECT COUNT(*) as c FROM personas WHERE is_builtin = 1").get() as any
  if (!count || count.c === 0) {
    const now = Date.now()
    const personas = [
      ['developer', 'Developer', 'You are an expert software engineer and architect. Help with code review, debugging, and architectural decisions. Prefer TypeScript, favor functional patterns, always consider edge cases.', 'claude-3-5-sonnet-20241022'],
      ['writer', 'Writer', 'You are a professional content writer and editor. Help with writing, editing, and improving text. Focus on clarity, tone, and audience.', 'claude-3-5-sonnet-20241022'],
      ['analyst', 'Analyst', 'You are a data analyst and researcher. Help analyze data, find patterns, and generate insights. Be precise with numbers.', 'claude-3-opus-20240229'],
      ['translator', 'Translator', 'You are a professional translator with expertise in Chinese, English, Japanese, and Korean. Provide accurate, natural-sounding translations.', 'claude-3-5-sonnet-20241022'],
      ['coach', 'Coach', 'You are a thoughtful life and productivity coach. Help organize thoughts, make decisions, and set goals. Ask clarifying questions.', 'claude-3-5-sonnet-20241022'],
    ]
    for (const [id, name, prompt, model] of personas) {
      d.prepare("INSERT OR IGNORE INTO personas (id, name, system_prompt, model_override, is_builtin, created_at) VALUES (?, ?, ?, ?, 1, ?)").run(id, name, prompt, model, now)
    }
  }

  const settings = [
    ['model', 'claude-3-5-sonnet-20241022'],
    ['theme', 'system'],
    ['shortcut_overlay', 'Alt+Space'],
    ['anthropic_api_key', ''],
    ['openai_api_key', ''],
    ['clipboard_monitoring', 'true'],
    ['context_awareness', 'true'],
  ]
  for (const [key, value] of settings) {
    d.prepare("INSERT OR IGNORE INTO settings (key, value, updated_at) VALUES (?, ?, ?)").run(key, value, Date.now())
  }
}
